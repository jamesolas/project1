package com.app.service.impl;

import java.util.Date;
import java.util.List;

import com.app.dao.EmployeeDAO;
import com.app.dao.impl.EmployeeDAOImpl;
import com.app.exception.BusinessException;
import com.app.model.Employee;
import com.app.model.Manager;
import com.app.model.Reimbursement;
import com.app.service.EmployeeService;

public class EmployeeServiceImpl implements EmployeeService {
	EmployeeDAO employeeDAOImpl = new EmployeeDAOImpl();

	@Override
	public int submitRequest(Employee employeeId, Manager managerId, double amount, Date date) throws BusinessException {
		String status = "pending";
		
		Reimbursement reimbursement = new Reimbursement(1, employeeId, managerId, status, amount, date);
		reimbursement = employeeDAOImpl.submitRequest(reimbursement);
		return 0;
	}

	@Override
	public List<Reimbursement> viewPendingRequests(int employeeId) throws BusinessException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Reimbursement> viewResolvedRequests(int employeeId) throws BusinessException {
		// TODO Auto-generated method stub
		return null;
	}

}
