package com.app.dao.impl;

import java.util.List;

import com.app.dao.EmployeeDAO;
import com.app.exception.BusinessException;
import com.app.model.Reimbursement;

public class EmployeeDAOImpl implements EmployeeDAO {

	@Override
	public int submitRequest(Reimbursement reimbursement) throws BusinessException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Reimbursement> viewPendingRequests(int employeeId) throws BusinessException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Reimbursement> viewResolvedRequests(int employeeId) throws BusinessException {
		// TODO Auto-generated method stub
		return null;
	}

}
